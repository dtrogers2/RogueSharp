﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RogueSharp
{
    //Legacy code
    class Coordinate
    {
        int x;
        int y;
        public ArrayList neighbor = new ArrayList();
        public static ArrayList coordinates = new ArrayList();
        bool blocked;
        public Coordinate(int x, int y)
        {
            this.x = x;
            this.y = y;
            blocked = DrawScreen.blockedMap[x, y];
            foreach (Coordinate item in coordinates)
            {
                if ((item.getX() == this.x && item.getY() == this.y - 1) ||
                    (item.getX() == this.x && item.getY() == this.y + 1) ||
                    (item.getX() == this.x + 1 && item.getY() == this.y) ||
                    (item.getX() == this.x - 1 && item.getY() == this.y)) { neighbor.Add(item); }
            }
        }
        public int getX()
        {
            return x;
        }
        public int getY()
        {
            return y;
        }

        public void setX(int x)
        {
            this.x = x;
        }

        public void setY(int y)
        {
            this.y = y;
        }

        public bool equals(Coordinate other)
        {
            if (other.getX() == getX() && other.getY() == getY()) return true;
            return false;
        }
        public bool equals(int x, int y)
        {
            if (x == getX() && y == getY()) return true;
            return false;
        }

        public bool isBlocked()
        {
            return blocked;
        }
    }
}
