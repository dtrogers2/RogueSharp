﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RogueSharp
{
    class Astar
    {
        

        
        public Node[] MoveAstar(int x1, int y1,int x2,int y2)
        {
            Node[,] nodeMap = (Node[,])Node.nodeMap.Clone();
            List<Node> openSet = new List<Node>();
            List<Node> closedSet = new List<Node>();
            var cameFrom = new Dictionary<Node, Node>();
            Node start = nodeMap[x1, y1];
            Node current = start;
            Node goal = nodeMap[x2, y2];
            current.gScore = 0;
            current.hScore = current.distanceBetween(goal);
            openSet.Add(current);
            

            do
            {
                Console.WriteLine("Open set count: "+ openSet.Count);
                Console.WriteLine("Closed set count: " + closedSet.Count);
                foreach (Node node in openSet)
                {
                    if (node.gScore+node.hScore <= current.gScore+current.hScore )
                    {
                        current = node;
                        break;
                    }
                }

                if (current.equals(goal))
                {
                    Node[] path = new Node[current.gScore];
                    int counter = current.gScore-1;
                    while (counter>0)
                    {
                        Console.WriteLine("Current gscore: " + current.gScore);
                        Console.WriteLine("Counter: " + counter);
                        Console.WriteLine("X: " + current.x + "Y: " + current.y);
                        Console.WriteLine("x came from: " + cameFrom[current].x + "y came from: " + cameFrom[current].y);
                        path[counter] = current;
                        current = cameFrom[current];
                        counter--;
                        if (path != null)
                        {
                            Console.WriteLine("it's not fucking null!");
                        }
                    }
                    if (path != null)
                    {
                        Console.WriteLine("it's REALLY not fucking null!");
                    }
                    return path;
                }

                closedSet.Add(current);
                openSet.Remove(current);

                List<Node> neighbors = new List<Node> { nodeMap[current.x, current.y - 1], nodeMap[current.x - 1, current.y],
                                                        nodeMap[current.x+1, current.y], nodeMap[current.x, current.y+1]};


                foreach (Node neighbor in neighbors)
                {
                    if (neighbor.visited) continue;
                    else
                    {
                        if (!neighbor.blocked)
                        {
                            openSet.Add(neighbor);
                            neighbor.setG(current);
                            neighbor.setH(goal);
                            cameFrom[neighbor] = current;
                        }
                        neighbor.visited = true;
                    }
                }
                

            } while ( openSet.Count > 0);
            return null;
        }

        /*
        public static Coordinate MoveAstar(Coordinate start, Coordinate goal)
        {
            List<Coordinate> closedSet = new List<Coordinate>();
            List<Coordinate> openSet = new List<Coordinate>();
            var gScore = new Dictionary<Coordinate, int>();
            var fScore = new Dictionary<Coordinate, int>();
            var cameFrom = new Dictionary<Coordinate, Coordinate>();
            gScore.Add(start, 0);
            openSet.Add(start);
            fScore.Add(start, distanceBetween(start, goal));
            Coordinate current = start;
            do
            {

                foreach (Coordinate item in openSet)
                {
                    if (gScore[item]+fScore[item] < gScore[current]+fScore[current])
                    { current = item; }
                }

                if (current.equals(goal)) {
                    return current;
                    while (cameFrom[current] != start)
                    {
                        current = cameFrom[current];
                        if (gScore[current] == 1)
                        {
                            return current;
                        }
                    }
        
                }

                closedSet.Add(current);
                openSet.Remove(current);

                foreach (Coordinate item in current.neighbor)
                {
                    int tempG = gScore[current] + distanceBetween(item,current);
                    if (closedSet.Contains(item)) { continue; }

                    if (!openSet.Contains(item) && !item.isBlocked())
                    {
                        //Adds neighbors not in the open set to the open set if the location isn't blocked
                        //Then calculates it's distance from the previous starting square, and
                        //The distance to the goal

                        gScore.Add(item, tempG);
                        fScore.Add(item, tempG + distanceBetween(item, goal));
                        openSet.Add(item);
                        cameFrom.Add(item, current);
                    }
                    else if (openSet.Contains(item))
                    {
                        if ((tempG + distanceBetween(item, goal)) < fScore[item])
                        {
                            fScore[item] = tempG;
                        }
                    }
                }

            } while ((openSet.Count > 0));
            return goal;
        }

        public int heuristicCostEstimate(Coordinate neighbor, Coordinate goal)
        {
            return (int)Math.Round(Math.Sqrt((neighbor.getX() - goal.getX())^2 + (neighbor.getY()-neighbor.getY())^2));
        }

        public static int distanceBetween(Coordinate neighbor, Coordinate goal)
        {
            return (int)Math.Round(Math.Sqrt((neighbor.getX() - goal.getX()) ^ 2 + (neighbor.getY() - goal.getY()) ^ 2));
                //((neighbor.getX() - goal.getX()) ^ 2 + (neighbor.getY() - neighbor.getY()) ^ 2) ^ (1 / 2);
        }*/
        

    }
}
