﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
namespace RogueSharp
{
    class Program
    {

        static void Main(string[] args)
        {
            MakeParty.enterParty();
            Console.Clear();
            MakeMap.GenerateMap();
            DrawScreen.DrawMap(true);
            Controls.Control();

        }
    }
}

            
